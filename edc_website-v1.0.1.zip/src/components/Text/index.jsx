import React from "react";

const sizeClasses = {
  txtMontserratRomanBold16: "font-bold font-montserrat",
  txtNunitoBold16: "font-bold font-nunito",
  txtInterBold16: "font-bold font-inter",
  txtMontserratRomanRegular40: "font-montserrat font-normal",
  txtMontserratRomanBold64: "font-bold font-montserrat",
};

const Text = ({ children, className = "", size, as, ...restProps }) => {
  const Component = as || "p";

  return (
    <Component
      className={`text-left ${className} ${size && sizeClasses[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
