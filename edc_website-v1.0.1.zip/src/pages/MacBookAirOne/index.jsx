import React from "react";

import { Img, Input, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MacBookAirOnePage = () => {
  const [searchboxvalue, setSearchboxvalue] = React.useState("");

  return (
    <>
      <div className="bg-cyan-400 flex flex-col font-montserrat items-center justify-start mx-auto p-[35px] sm:px-5 w-full">
        <div className="flex flex-col items-end justify-start max-w-[1174px] mb-[857px] mt-[11px] mx-auto md:px-5 w-full">
          <div className="flex md:flex-col flex-row gap-[31px] items-center justify-between w-full">
            <Img
              className="sm:flex-1 h-[101px] md:h-auto object-cover w-[102px] sm:w-full"
              src="images/img_image1.png"
              alt="imageOne"
            />
            <div className="md:h-[82px] h-[84px] relative w-[89%] md:w-full">
              <div className="absolute flex flex-col font-montserrat h-full inset-y-[0] items-start justify-end left-[0] my-auto p-[31px] sm:px-5 w-[90%]">
                <div className="flex flex-row gap-8 items-center justify-start md:ml-[0] ml-[63px] w-auto">
                  <Text
                    className="capitalize text-base text-white-A700 w-auto"
                    size="txtMontserratRomanBold16"
                  >
                    Home
                  </Text>
                  <Text
                    className="capitalize text-base text-white-A700 w-auto"
                    size="txtMontserratRomanBold16"
                  >
                    About
                  </Text>
                  <div className="flex flex-col font-inter items-center justify-center w-auto">
                    <Text
                      className="capitalize text-base text-white-A700 w-auto"
                      size="txtInterBold16"
                    >
                      Events
                    </Text>
                  </div>
                  <Text
                    className="capitalize text-base text-white-A700 w-auto"
                    size="txtMontserratRomanBold16"
                  >
                    Team
                  </Text>
                </div>
              </div>
              <Input
                name="searchbox"
                placeholder="Search for anything"
                value={searchboxvalue}
                onChange={(e) => setSearchboxvalue(e)}
                className="capitalize font-inter leading-[normal] p-0 placeholder:text-white-A700 sm:px-5 text-left text-sm text-white-A700 w-full"
                wrapClassName="border-2 border-solid border-white-A700 flex inset-y-[0] my-auto px-[35px] py-3 right-[0] rounded-[15px] w-[33%]"
                prefix={
                  <Img
                    className="cursor-pointer h-5 mr-3 right-[1%] absolute my-auto"
                    src="images/img_search.svg"
                    alt="search"
                  />
                }
                suffix={
                  <CloseSVG
                    fillColor="#ffffff"
                    className="cursor-pointer h-5 absolute my-auto"
                    onClick={() => setSearchboxvalue("")}
                    style={{
                      visibility:
                        searchboxvalue?.length <= 0 ? "hidden" : "visible",
                    }}
                    height={20}
                    width={20}
                    viewBox="0 0 20 20"
                  />
                }
              ></Input>
            </div>
          </div>
          <div className="h-[268px] md:h-[404px] mt-[136px] relative w-[94%] md:w-full">
            <Text
              className="absolute bottom-[0] leading-[75.00px] left-[0] md:text-5xl text-[64px] text-white-A700 tracking-[2.00px]"
              size="txtMontserratRomanBold64"
            >
              <span className="text-blue_gray-900 font-montserrat text-left font-bold">
                E
              </span>
              <span className="text-white-A700 font-montserrat text-left font-bold">
                <>
                  ntrepreneurship
                  <br />
                </>
              </span>
              <span className="text-blue_gray-900 font-montserrat text-left font-bold">
                D
              </span>
              <span className="text-white-A700 font-montserrat text-left font-bold">
                <>
                  evelopment <br />
                </>
              </span>
              <span className="text-blue_gray-900 font-montserrat text-left font-bold">
                C
              </span>
              <span className="text-white-A700 font-montserrat text-left font-bold">
                ell
              </span>
            </Text>
            <Img
              className="absolute h-[268px] inset-y-[0] my-auto object-cover right-[0] w-2/5"
              src="images/img_1x11.png"
              alt="1xEleven"
            />
          </div>
          <div className="flex sm:flex-col flex-row gap-[49px] items-center justify-center mt-[300px] w-[33%] md:w-full">
            <div className="bg-blue_gray-900_01 flex flex-col items-center justify-start p-[18px] rounded-[3px] shadow-bs">
              <Text
                className="sm:text-4xl md:text-[38px] text-[40px] text-center text-white-A700"
                size="txtMontserratRomanRegular40"
              >
                2
              </Text>
              <Text
                className="my-1 text-base text-center text-white-A700"
                size="txtNunitoBold16"
              >
                Days Event
              </Text>
            </div>
            <div className="bg-blue_gray-900_01 flex flex-col items-center justify-start p-[18px] rounded-[3px] shadow-bs">
              <Text
                className="sm:text-4xl md:text-[38px] text-[40px] text-center text-white-A700"
                size="txtMontserratRomanRegular40"
              >
                15+
              </Text>
              <Text
                className="my-1 text-base text-center text-white-A700"
                size="txtNunitoBold16"
              >
                Speakers
              </Text>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default MacBookAirOnePage;
