module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        blue_gray: { 900: "#242b33", "900_01": "#232b33" },
        black: { "900_14": "#00000014" },
        white: { A700: "#ffffff" },
        cyan: { 400: "#32b1d9" },
      },
      fontFamily: {
        montserrat: "Montserrat",
        nunito: "Nunito",
        inter: "Inter",
      },
      boxShadow: { bs: "0px 15px  30px 0px #00000014" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
